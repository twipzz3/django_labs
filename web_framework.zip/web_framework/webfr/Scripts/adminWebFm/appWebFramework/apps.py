from django.apps import AppConfig

def app(environ, start_response):
    response_body = b"Hello, World!"
    status = "200 OK"
    start_response(status, headers=[])
    return iter([response_body])

class AppwebframeworkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appWebFramework'
