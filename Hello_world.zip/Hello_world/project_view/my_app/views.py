from django.shortcuts import render
from django.http import HttpResponse
from .models import Categories
def my_view(request):
    app_context = {
        'number': 1111,
        'name': "Dima"
    }
    category = Categories.objects.get(id=1)
    print(category.category_name)
    return render(request, "home.html", app_context)
    

