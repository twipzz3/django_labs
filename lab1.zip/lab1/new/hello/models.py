from django.db import models

class TestTable(models.Model):
    name = models.CharField(max_length=50)
    age = models.IntegerField()
# Create your models here.

#1 to 1
class Place(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=80)

    def str(self):
        return "%s the place" % self.name

class Restaurant(models.Model):
    place = models.OneToOneField(
        Place,
        on_delete=models.CASCADE,
        primary_key=True,
    )
    serves_hot_dogs = models.BooleanField(default=False)
    serves_pizza = models.BooleanField(default=False)

    def str(self):
        return "%s the restaurant" % self.place.name

class Waiter(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)

    def str(self):
        return "%s the waiter at %s" % (self.name, self.restaurant)


#many to 1
class Reporter(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField()

    def str(self):
        return "%s %s" % (self.first_name, self.last_name)

class Article(models.Model):
    headline = models.CharField(max_length=100)
    pub_date = models.DateField()
    reporter = models.ForeignKey(Reporter, on_delete=models.CASCADE)

    def str(self):
        return self.headline

    class Meta:
        ordering = ['headline']

#many to many
class Publication(models.Model):
    title = models.CharField(max_length=30)

    class Meta:
        ordering = ['title']

    def str(self):
        return self.title

class Magazine(models.Model):
    headline = models.CharField(max_length=100)
    publications = models.ManyToManyField(Publication)

    class Meta:
        ordering = ['headline']
#changed
    def str(self):
        return self.headline

class Categories(models.Model):
    category_name = models.CharField(max_length=50)
    def __str__(self):
        return self.category_name
class Products(models.Model):
    product_name = models.CharField(max_length=50)
    price = models.IntegerField()
    category = models.ForeignKey(Categories, on_delete=models.CASCADE)

    def __str__(self):
        return "{}: {}".format(self.category.category_name, self.product_name, )