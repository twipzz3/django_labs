from django.contrib import admin

from.models import Products
admin.site.register(Products)

from.models import Categories
admin.site.register(Categories)
